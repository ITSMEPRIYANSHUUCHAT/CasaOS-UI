<!--
 * @Author: Jerryk jerry@icewhale.org
 * @Date: 2022-07-29 14:33:37
 * @LastEditors: Jerryk jerry@icewhale.org
 * @LastEditTime: 2022-07-29 14:33:44
 * @FilePath: /CasaOS-UI/src/components/filebrowser/shared/EmptyHolder.vue
 * @Description: 
 * 
 * Copyright (c) 2022 by IceWhale, All Rights Reserved. 
-->
<template>
  <div>
    
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>