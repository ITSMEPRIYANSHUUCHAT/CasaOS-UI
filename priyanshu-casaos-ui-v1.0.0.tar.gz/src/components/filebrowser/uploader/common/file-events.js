/*
 * @LastEditors: zhanghengxin ezreal.zhang@icewhale.org
 * @LastEditTime: 2023/4/24 上午11:20
 * @FilePath: /CasaOS-UI/src/components/filebrowser/uploader/common/file-events.js
 * @Description:
 *
 * Copyright (c) 2023 by IceWhale, All Rights Reserved.

 */

const events = ['fileProgress', 'fileSuccess', 'fileComplete', 'fileError']

export default events
