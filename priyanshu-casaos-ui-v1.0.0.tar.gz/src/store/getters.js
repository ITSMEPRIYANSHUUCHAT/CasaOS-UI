/*
 * @Author: Jerryk jerry@icewhale.org
 * @Date: 2022-06-02 19:49:06
 * @LastEditors: Jerryk jerry@icewhale.org
 * @LastEditTime: 2022-06-02 19:49:18
 * @FilePath: \CasaOS-UI\src\store\getter.js
 * @Description: 
 * 
 * Copyright (c) 2022 by IceWhale, All Rights Reserved. 
 */
const getters = {}
export default getters